/*
Project: 	 lyrebird (assignment 1)
Author: 	 Iykon Pan
SFU user name:	 lykonp
lecture section: D100
instructor: 	 Brian G. Booth
TA:		 Scott Kristjanson
*/
#include <stdio.h>
#include "decrypt.h"

const int base=41;
const int MAXLENGTH=142;
const ull N=(ull)429443481*10+7,D=1921821779;

int main(int argc, char **argv){
	char *tweets,*decrypted;
	FILE *finp, *foutp;
	finp=fopen(argv[1],"r");
	foutp=fopen(argv[2],"w+");
	tweets = (char *) malloc (MAXLENGTH*sizeof(char));
	decrypted = (char *) malloc (MAXLENGTH*sizeof(char));
	while(fgets(tweets,MAXLENGTH,finp)!=NULL){//read an encrypted tweet
		decrypted[0]=0;
		decrypt(tweets,decrypted);
		fprintf(foutp,"%s\n",decrypted);
	}
	free(tweets);
	free(decrypted);
	fclose(finp);
	fclose(foutp);
}
